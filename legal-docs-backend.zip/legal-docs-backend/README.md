# Secure Legal Document Management System: Backend

Backend for secure management of legal investigation documents
(auth + MFA, RBAC, AES-256-GCM encryption, AI classification, MinIO storage,
hash anchoring, digital signatures, tamper-proof audit log).

**Current status: Phase 0 (project skeleton, infra, health checks)**

## Structure
```
app/
  main.py                 FastAPI app + lifespan
  core/                   config (env vars), logging  (later: security, crypto)
  db/                     SQLAlchemy engine/session/Base
  models/                 ORM models (Phase 1+)
  services/               storage.py (MinIO)  (later: encryption, ocr, ledger, audit)
  api/v1/                 router + endpoints (health now; auth, documents later)
alembic/                  DB migrations
tests/
```

## Quick start
```bash
cp .env.example .env          # then edit the passwords/keys
docker compose up -d --build  # postgres + minio + api
```
- API docs: http://localhost:8000/docs
- Liveness: http://localhost:8000/api/v1/health
- Readiness (DB + MinIO): http://localhost:8000/api/v1/health/ready
- MinIO console: http://localhost:9001 (login with MINIO_ACCESS_KEY / MINIO_SECRET_KEY)

## Running the API locally (without the api container)
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
docker compose up -d postgres minio
uvicorn app.main:app --reload
pytest -q
```

## Migrations
```bash
alembic revision --autogenerate -m "message"
alembic upgrade head
```

## Roadmap
0. Setup (done)  1. Auth, MFA, RBAC  2. Upload + encryption + storage
3. Audit log  4. Signatures + ledger  5. AI/OCR  6. Search + sharing
