import logging

import urllib3
from minio import Minio

from app.core.config import settings

logger = logging.getLogger(__name__)


def get_minio_client() -> Minio:
    # Short timeouts + 1 retry so health checks fail fast instead of hanging.
    http_client = urllib3.PoolManager(
        timeout=urllib3.Timeout(connect=2.0, read=3.0),
        retries=urllib3.Retry(total=1, backoff_factor=0.2),
    )
    return Minio(
        settings.MINIO_ENDPOINT,
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=settings.MINIO_SECURE,
        http_client=http_client,
    )


def ensure_bucket() -> None:
    """Create the documents bucket if it does not exist yet."""
    client = get_minio_client()
    if not client.bucket_exists(settings.MINIO_BUCKET):
        client.make_bucket(settings.MINIO_BUCKET)
        logger.info("Created MinIO bucket '%s'", settings.MINIO_BUCKET)
