from fastapi.testclient import TestClient

from app.api.v1.endpoints import health
from app.main import app

client = TestClient(app)


def test_liveness():
    r = client.get("/api/v1/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_readiness_ok(monkeypatch):
    monkeypatch.setattr(health, "check_database", lambda: True)
    monkeypatch.setattr(health, "check_storage", lambda: True)
    r = client.get("/api/v1/health/ready")
    assert r.status_code == 200
    assert r.json() == {"status": "ready", "checks": {"database": True, "storage": True}}


def test_readiness_degraded(monkeypatch):
    monkeypatch.setattr(health, "check_database", lambda: True)
    monkeypatch.setattr(health, "check_storage", lambda: False)
    r = client.get("/api/v1/health/ready")
    assert r.status_code == 503
    assert r.json()["status"] == "degraded"
    assert r.json()["checks"]["storage"] is False
