from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Parent class for all ORM models. Import models in app/models/__init__.py
    so Alembic can discover them."""
