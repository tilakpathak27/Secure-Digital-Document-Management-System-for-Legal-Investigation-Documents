import logging

from fastapi import APIRouter, Response, status
from sqlalchemy import text

from app.core.config import settings
from app.db.session import engine
from app.services.storage import get_minio_client

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/health", tags=["Health"])


def check_database() -> bool:
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception as exc:  # noqa: BLE001
        logger.warning("Database health check failed: %s", exc.__class__.__name__)
        return False


def check_storage() -> bool:
    try:
        return get_minio_client().bucket_exists(settings.MINIO_BUCKET)
    except Exception as exc:  # noqa: BLE001
        logger.warning("MinIO health check failed: %s", exc.__class__.__name__)
        return False


@router.get("", summary="Liveness: is the API process up?")
def liveness() -> dict:
    return {"status": "ok", "app": settings.APP_NAME, "version": settings.APP_VERSION}


@router.get("/ready", summary="Readiness: are Postgres and MinIO reachable?")
def readiness(response: Response) -> dict:
    checks = {"database": check_database(), "storage": check_storage()}
    ready = all(checks.values())
    if not ready:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {"status": "ready" if ready else "degraded", "checks": checks}
